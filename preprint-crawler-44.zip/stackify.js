/**
 * Stackify Node APM Configuration
 */
exports.config = {
  /**
   * Your application name.
   */
  application_name: 'Preprint Crawler',
  /**
   * Your environment name.
   */
  environment_name: 'awsone'
}
